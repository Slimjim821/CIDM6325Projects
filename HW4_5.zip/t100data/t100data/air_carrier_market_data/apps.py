from django.apps import AppConfig


class AirCarrierMarketDataConfig(AppConfig):
    name = 'air_carrier_market_data'
